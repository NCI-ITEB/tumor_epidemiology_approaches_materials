# Emerging Approaches for Tumor Analyses in Epidemiological Studies 2022-2023
# Session 8 Practical Session - Identifying Cancer Drivers 
# dndscv practice

########## Install and load dndscv package in R ------------------

# install packages needed for this part of the practical session if they are not already installed
packages_req <- c('tidyverse','devtools','scales','hrbrthemes')
pkg_check_fcn <-lapply(packages_req,function(x){
  #if a package in the packages_req vector is not installed, install it
  if(!(x %in% installed.packages())){
    install.packages(x, dependencies = TRUE, repos=structure(c(CRAN="http://cloud.r-project.org/")))
    #load the package after installing it
    library(x, character.only = TRUE)
    #else statement for when the packages are already installed
  }else{
    #load the package already installed into the workspace
    library(x, character.only = TRUE)
    #print(paste0(x,":" , "Package already installed"))
  }
  
})

# Use this command if you have not yet installed dndscv in R
install_github("im3sanger/dndscv")

# load dndscv
library(dndscv)

########## Load the data into R -----------------

# Make sure current working directory is the path to the session8_dndscv folder
getwd()

# Mac:
#   [1] "/Users/[username]/Downloads/session8_dndscv"
# Windows:
#   [1] "C:/Users/[username]/Downloads/session8_dndscv"

# If the working directory is not the session8_dndscv directory, use the setwd() command 
# to set this directory as the working directory. 
setwd("/Users/[username]/Downloads/session8_dndscv")

# Mac:
#   setwd("/Users/[username]/Downloads/session8_dndscv")
# Windows:
#   setwd("C:/Users/[username]/Downloads/session8_dndscv")

# Run getwd() again to make sure the working directory is now correct
getwd()

# Mac:
#   [1] "/Users/[username]/Downloads/session8_dndscv"
# Windows:
#   [1] "C:/Users/[username]/Downloads/session8_dndscv"

# Load data
sherlock_mdata <- read_delim("sherlock_only_mutations_top200.txt.gz")

########## Explore and Prepare Data ----------

# Check dimensions of the data
dim(sherlock_mdata)

# Check first several lines of the data
head(sherlock_mdata)

# Change column names to match the required columns name to run dndscv
# check current column names
colnames(sherlock_mdata)
# [1] "Tumor_Sample_Barcode" "Chr"                 
# [3] "Start"                "Ref"                 
# [5] "Alt"
colnames(sherlock_mdata) <- c('sampleID', 'chr','pos','ref','mut')
colnames(sherlock_mdata)
#[1] "sampleID" "chr"      "pos"      "ref"      "mut"

# Create object to store output
dndsout <- NULL

# Load the covariate file needed to run dndscv
load("covariates_hg19_hg38_epigenome_pcawg.rda")

#Download RefCDS data
download.file("https://github.com/im3sanger/dndscv_data/raw/master/data/RefCDS_human_GRCh38_GencodeV18_recommended.rda",
              destfile = "./RefCDS_human_GRCh38_GencodeV18_recommended.rda")

# Additional information
# load the genome reference CDS file if you want to see what it looks like
# load('RefCDS_human_GRCh38_GencodeV18_recommended.rda')

########## Run dndscv ----------
dndsout <-  dndscv(mutations = sherlock_mdata, refdb = 'RefCDS_human_GRCh38_GencodeV18_recommended.rda',cv =covs)
# [1] Loading the environment...
# [2] Annotating the mutations...
# Note: 1 samples excluded for exceeding the limit of mutations per sample (see the max_coding_muts_per_sample argument in dndscv). 199 samples left after filtering.
# Note: 535 mutations removed for exceeding the limit of mutations per gene per sample (see the max_muts_per_gene_per_sample argument in dndscv)
# 11% ...
# 21% ...
# 32% ...
# 42% ...
# 53% ...
# 63% ...
# 74% ...
# 85% ...
# 95% ...
# [3] Estimating global rates...
# [4] Running dNdSloc...
# [5] Running dNdScv...
# Regression model for substitutions (theta = 6.58).
# Regression model for indels (theta = 5.2)
# Warning messages:
#   1: In dndscv(mutations = sherlock_mdata, refdb = "RefCDS_human_GRCh38_GencodeV18_recommended.rda",  :
#                  Mutations observed in contiguous sites within a sample. Please annotate or remove dinucleotide or complex substitutions for best results.
#                2: In dndscv(mutations = sherlock_mdata, refdb = "RefCDS_human_GRCh38_GencodeV18_recommended.rda",  :
#                               Same mutations observed in different sampleIDs. Please verify that these are independent events and remove duplicates otherwise.

# Extract results of neutrality tests at the gene level via the dNdScv method
sel_cv <- dndsout$sel_cv
sel_cv %>% View()

dnds_wvals <- sel_cv %>% filter(gene_name%in% c('TP53','KEAP1','KRAS')) %>% select(gene_name, starts_with('w'))
dnds_wvals %>% View()

signif_genes = sel_cv[sel_cv$qglobal_cv<0.1, c("gene_name","qglobal_cv")]

sel_cv %>%
  filter(qglobal_cv<0.1) %>%
  select(gene_name,starts_with('q')) %>%
  mutate(gene_name=factor(gene_name),gene_name=fct_reorder(gene_name,qglobal_cv)) %>%
  pivot_longer(cols = starts_with('q')) %>% mutate(name=factor(name)) %>%
  mutate(value=if_else(value==0,1e-16,value)) %>%
  ggplot(aes(gene_name,-log10(value),group=name,col=name))+
  geom_line() + 
  geom_point() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

head(dndsout$annotmuts)

sizedata <- n_distinct(sherlock_mdata$sampleID) - 1 # number of samples
#[1] 199

freqdata <- dndsout$annotmuts %>%
  filter(gene %in% signif_genes$gene_name) %>%
  filter(impact!="Synonymous") %>%
  count(sampleID,gene) %>%
  select(-n) %>%
  count(gene) %>%
  arrange(desc(n)) %>%
  mutate(Freq=100*n/sizedata)

p <- sel_cv %>% filter(gene_name %in% signif_genes$gene_name) %>%
  left_join(freqdata,by=c('gene_name'='gene')) %>%
  mutate(gene_name=factor(gene_name),gene_name=fct_reorder(gene_name,qglobal_cv)) %>%
  pivot_longer(cols = starts_with('q')) %>%
  mutate(value=if_else(value==0,1e-16,value)) %>%
  ggplot(aes(Freq,-log10(value),fill=-log10(value)))+
  facet_wrap(~name) +
  geom_point(pch=21,size=4,col="white",stroke=0.5)+
  ggrepel::geom_text_repel(aes(label=gene_name),size=3.5)+
  scale_x_continuous(breaks = breaks_pretty())+
  scale_y_continuous(breaks = breaks_pretty())+
  labs(x='Mutational Frequency (%)',y='-log10(qvalue)')+
  theme_ipsum(axis_title_just = 'm',axis_title_size = 14,grid = 'XYx',ticks = TRUE,axis = FALSE)+
  theme(legend.position = 'none') + coord_cartesian(clip = "off")

