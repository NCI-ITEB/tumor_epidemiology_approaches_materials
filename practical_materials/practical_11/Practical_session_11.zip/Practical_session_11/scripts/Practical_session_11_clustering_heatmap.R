

#library(tidyverse)


### prepare data matrix of DE genes for clustering in GenePattern

normalized_counts_2 <- normalized_counts %>% select(-1)
lognorm <- log2(normalized_counts_2+1)
resSig <- subset(res, padj < 0.05 & abs(log2FoldChange)>1)
resSig <- resSig[ order(abs(resSig$log2FoldChange),decreasing=TRUE), ]
outfile <- lognorm[rownames(resSig),]
outfile <- data.frame(outfile)%>%mutate(gene_name=rownames(outfile),.before=1)
outfilestr <-  "Practical_11_DESeq2_log_normalized_counts_up+down_genes.csv"
write_delim(outfile,file=outfilestr,delim=",")



### prepare 1000 DE genes for tidyHeatmap
# CHANGE PATHS
# get de genes
de_genes<-
  bind_rows(res_down_genes,res_up_genes)%>%
  arrange(-abs(log2FoldChange))%>%
  .[1:1000,]%>%
  pull(gene_name)



# produce heatmap
#library(tidyHeatmap)
heatmap_in<-normalized_counts%>%
  filter(gene_name %in% de_genes)%>%
  pivot_longer(-1,names_to = "Sample",values_to = "Exp")%>%
  left_join(metadata,by=c("Sample"="UID"))%>%
  group_by(gene_name)%>%
  mutate(Exp=(Exp-mean(Exp))/sd(Exp))%>%
  ungroup()
# expression is transformed to z-score for better comparison between genes

#examine the new table structure
heatmap_in

#draw heatmap
tidyHeatmap::heatmap(.data = heatmap_in,
                     .row = gene_name,
                     .column=Sample,
                     .value = Exp,
                     clustering_method_columns="ward.D2",
                     clustering_method_rows="ward.D2",
                     show_row_names=FALSE)%>%
  add_tile(Type)%>%
  add_tile(stage,palette = c('#1b9e77','#d95f02','#7570b3'))

