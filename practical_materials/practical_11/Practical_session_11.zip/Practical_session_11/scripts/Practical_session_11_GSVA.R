
### GSVA

# install and load required packages
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
if (!requireNamespace("msigdb", quietly = TRUE))
  BiocManager::install("msigdb")
if (!requireNamespace("GSEABase", quietly = TRUE))
  BiocManager::install("GSEABase")
library(msigdb)
library(GSEABase)

# get genesets: org=organism, id=gene id format
msigdb.hs = getMsigdb(org = 'hs', id = 'SYM')

# extract hallmark genesets
hallmarks = subsetCollection(msigdb.hs, 'h')

# install GSVA if necessary, then load
if (!requireNamespace("GSVA", quietly = TRUE))
  BiocManager::install("GSVA")
library(GSVA)

# run gsva
gsva_out<-GSVA::gsva(as.matrix(normalized_counts[,-1]),geneIds(hallmarks))

View(gsva_out)

# install broom package if necessary
if (!requireNamespace("broom", quietly = TRUE))
  install.packages("broom")


gsva_signif<-
  # start by reformatting gsva output similar to how we did with the heatmap
  gsva_out%>%
  as.data.frame()%>%
  rownames_to_column("pathway")%>%
  pivot_longer(-1,names_to="UID",values_to="Enrich")%>%
  left_join(metadata)%>%
  # ensure that enrichment values are w/ respect to tumor expression
  mutate(Type=factor(Type,levels=c("Tumor","Normal")))%>%
  # perform t.test, use the `tidy function` to keep output in table format 
  group_by(pathway)%>%
  summarise(t.test(Enrich~Type)%>%broom::tidy())%>%
  mutate(fdr=p.adjust(p.value,method="BH"))

# subset to the top 10 most significant pathway changes
gsva_signif%>%
  arrange(fdr)%>%
  .[1:10,]


