
# Normalization and DE Analysis
# Emerging Approaches for Tumor Analyses in Epidemiological Studies
# Practical Session 11
# April 2023

# Prepare environment --------------------------------------------------------------
# Load the necessary packages for this part of the practical session
# Install multiple packages at once
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install(c("DESeq2", "tidyHeatmap", "GSVA", "tidyverse","msigdb", "GSEABase"))

#Once the packages are installed, you can load them into your R session using the library() function
library(DESeq2)
library(tidyHeatmap)
library(msigdb)
library(GSEABase)
library(GSVA)
library(tidyverse)

# Make sure you are currently in the Practical_session_11 folder
getwd()
# Mac
# "/Users/[username]/Downloads/Practical_session_11/"
# 
# Windows
# "C:/Users/[username]/Downloads/Practical_session_11/"
# 
# If you are not, use the setwd() command:
#   
# setwd("/Users/[username]/Downloads/Practical_session_11/")

# Normalization --------------------------------------------------------------

# Method One: TPM normalization- Transcripts Per Million - Not reviewing this during the session, provided as a supplement
# read in sample annotations
metadata <- read_delim('Practical_11_samples_clinical.txt')
# read in raw counts output from htseq
htseq_output <- read_delim('Practical_11_htseq_counts.txt') %>% data.frame() 
# rename UID to gene_name (to be used later)
htseq_output <- dplyr::rename(htseq_output, gene_name = UID)
# set row names to gene names and remove the gene_name column (the first column in the dataframe)
rownames(htseq_output) <- htseq_output$gene_name
htseq_output <- htseq_output %>% select(-1)
gene_lengths <- read_delim('gencode.v35.annotation.length.featureCounts.ByGeneName.txt')

head(metadata) %>% View()

head(htseq_output) %>% View()

head(gene_lengths) %>% View()

# filter out any genes where the read counts across samples are not greater than or equal to 10
htseq_output <- htseq_output %>%
  dplyr::filter(rowSums(.) >= 10)
# add gene_name column back in and reset rownames to NULL (all columns to calculate rowSums needed to be numeric- gene_name was not numeric)
htseq_output <- htseq_output %>% mutate(gene_name = rownames(htseq_output) ,.before = 1)
rownames(htseq_output) <- NULL
# join htseq data with gene length data so we can account for gene length in normalization
htseq_output <- htseq_output %>% left_join(gene_lengths)
# make the data frame of wider format to divide each count by the corresponding gene length 
htseq_output <- htseq_output %>% pivot_longer(cols = starts_with('Sample'))
# divide each count by corresponding gene length
htseq_output <- htseq_output %>% mutate(gene_length_norm = value/length)
# values that have now been divided by gene length; put back into dataframe where each sample is a column - Sample RPKs
htseq_tmp <- htseq_output %>% pivot_wider(names_from = name, values_from = gene_length_norm) %>% group_by(gene_name) %>% summarise(across(starts_with("Sample"), ~sum(., na.rm = TRUE)))
# total RPKs per each sample
htseq_tmp2 <- htseq_output %>% group_by(name) %>% summarise(sum(gene_length_norm)) %>% mutate(total = `sum(gene_length_norm)`) %>% select(-2)
# calculate scaling factor by taking total RPK for a sample and dividing it by 1000000 (i.e. transcripts per MILLION) 
htseq_tmp2 <- htseq_tmp2 %>% mutate(scaling_factor = total/1000000)

# divide each sample by the appropriate scaling factor determined in the previous line of code
# R loop to divid each column by the correct value
sample_names <- paste0('Sample',rep(1:20))
i <- 1
for(each in sample_names){
sample_name <- paste0('Sample',i)
print(sample_name)
#scaling_factor <- htseq_tmp2$scaling_factor[which(htseq_tmp2$name == 'Sample1')]
scaling_factor <- htseq_tmp2$scaling_factor[which(htseq_tmp2$name == sample_name)]
htseq_tmp[,sample_name] <- htseq_tmp[,sample_name]/scaling_factor
i <- i + 1

}

# save the normalized counts to a file
htseq_normalized_tpm <- htseq_tmp
write_delim(htseq_normalized_tpm, file= 'htseq_normalized_tpm.csv',delim = ',')

# --------------------------------------------------------------

# Method Two: Normalization via DESeq
# read in sample annotations
metadata <- read_delim('Practical_11_samples_clinical.txt')
# read in raw counts output from htseq
htseq_output <- read_delim('Practical_11_htseq_counts.txt') %>% data.frame()
# rename UID to gene_name (to be used later)
htseq_output <- dplyr::rename(htseq_output, gene_name = UID)
# set row names to gene names and remove the gene_name column (the first column in the dataframe)
rownames(htseq_output) <- htseq_output$gene_name
htseq_output <- htseq_output %>% select(-1)

head(metadata) %>% View()

head(htseq_output) %>% View()

head(gene_lengths) %>% View()

# set up variables to include in the model- Type (Tumor vs. Normal) and stage (1,2,3)
# need to set up as factors with the appropriate reference level
metadata$Type <- factor(metadata$Type, levels = c("Normal", "Tumor"))
# recode the original STAGE variable to a new variable, stage, with levels 1, 2, and 3
metadata <- metadata %>% 
  mutate(stage=case_when(str_detect(STAGE,'^I[AB]')~1,
                         str_detect(STAGE,'^II[AB]')~2,
                         str_detect(STAGE,'^III[AB]')~3,
                         TRUE~888
  ))
metadata$stage <- factor(metadata$stage, levels = c("1", "2", "3"))

# check that our column names in our raw counts are in the same order as the sample annotation sample IDs
all.equal(colnames(htseq_output), metadata$UID)
# [1] TRUE

# set up function to generate a DESeqDataSet
# using our htseq raw counts, sample annotations, and our model (which includes stage and Type)
dds <- DESeqDataSetFromMatrix(countData = htseq_output,
                              colData = metadata,
                              design= ~ stage + Type)

# filter out any genes where the read counts across samples are not greater than or equal to 10
keep <- rowSums(counts(dds)) >= 10
dds <- dds[keep,]

# normalization steps
dds <- estimateSizeFactors(dds)
normalized_counts <- counts(dds, normalized=TRUE)
normalized_counts <- data.frame(normalized_counts)
normalized_counts <- normalized_counts %>% mutate(gene_name = rownames(normalized_counts), .before = 1)


# save normalized counts to a file
write_delim(data.frame(normalized_counts), file = 'htseq_normalized_DESeq.csv', delim = ',')

# PCA Exploration --------------------------------------------------------------
# starting over as if this is the first step before setting up DE analysis
# read in sample annotations
metadata <- read_delim('Practical_11_samples_clinical.txt')
# read in raw counts output from htseq
htseq_output <- read_delim('Practical_11_htseq_counts.txt') %>% data.frame()
# rename UID to gene_name (to be used later)
htseq_output <- dplyr::rename(htseq_output, gene_name = UID)
# set row names to gene names and remove the gene_name column (the first column in the dataframe)
rownames(htseq_output) <- htseq_output$gene_name
htseq_output <- htseq_output %>% select(-1)

# set up variables to include in the model- Type (Tumor vs. Normal) and stage (1,2,3)
# need to set up as factors with the appropriate reference level
metadata$Type <- factor(metadata$Type, levels = c("Normal", "Tumor"))
# recode the original STAGE variable to a new variable, stage, with levels 1, 2, and 3
metadata <- metadata %>% 
  mutate(stage=case_when(str_detect(STAGE,'^I[AB]')~1,
                         str_detect(STAGE,'^II[AB]')~2,
                         str_detect(STAGE,'^III[AB]')~3,
                         TRUE~888
  ))
metadata$stage <- factor(metadata$stage, levels = c("1", "2", "3"))

all.equal(colnames(htseq_output), metadata$UID)
# [1] TRUE

# using our htseq raw counts, sample annotations, and our model (which includes stage and Type)
dds <- DESeqDataSetFromMatrix(countData = htseq_output,
                              colData = metadata,
                              design= ~ stage + Type)

# filter out any genes where the read counts across samples are not greater than or equal to 10
keep <- rowSums(counts(dds)) >= 10
dds <- dds[keep,]

dds_norm <- vst(dds)

# PCA for Type and stage individually
# plotPCA(
#   dds_norm,
#   intgroup = "Type"
# )
# 
# plotPCA(
#   dds_norm,
#   intgroup = "stage"
# )

plotPCA(
  dds_norm,
  intgroup = c("Type", "stage")
)

pca_results <- plotPCA(
  dds_norm,
  intgroup = c("Type","stage"),
  returnData = TRUE
)

annotated_pca_plot <- ggplot(
  pca_results,
  aes(
    x = PC1,
    y = PC2,
    # plot points with different colors for tumor vs normal
    color = Type,
    # plot points with different shapes for each stage
    shape = stage
  )
) +
  # Make a scatter plot
  geom_point()

# display annotated plot
annotated_pca_plot

# Differential Expression Analysis using DESeq2 --------------------------------------------------------------
# DESeq uses raw counts and carries out normalization within the function itself
# RUN LINES 225- 255 if you did not run PCA in previous section
# # start over as if we did not complete the normalization above
# metadata <- read_delim('Practical_11_candidate_samples_TP53_N20_recode.txt')
# # read in raw counts output from htseq
# htseq_output <- read_delim('Practical_11_htseq_counts.txt') %>% data.frame()
# # set row names to gene names and remove the gene_name column (the first column in the dataframe)
# rownames(htseq_output) <- htseq_output$UID
# htseq_output <- htseq_output %>% select(-1)
# 
# # set up variables to include in the model- Type (Tumor vs. Normal) and stage (1,2,3)
# # need to set up as factors with the appropriate reference level
# metadata$Type <- factor(metadata$Type, levels = c("Normal", "Tumor"))
# # recode the original STAGE variable to a new variable, stage, with levels 1, 2, and 3
# metadata <- metadata %>% mutate(stage = if_else(STAGE == 'IA', 1,
#                                                 if_else(STAGE == 'IB', 1,
#                                                         if_else(STAGE == 'IIA' , 2,
#                                                                 if_else(STAGE == 'IIB', 2,
#                                                                         if_else(STAGE == 'IIIA', 3,
#                                                                                 if_else(STAGE == 'IIIB', 3, 888)))))))
# 
# metadata$stage <- factor(metadata$stage, levels = c("1", "2", "3"))
# 
# # using our htseq raw counts, sample annotations, and our model (which includes stage and Type)
# dds <- DESeqDataSetFromMatrix(countData = htseq_output,
#                               colData = metadata,
#                               design= ~ stage + Type)
# 
# # filter out any genes where the read counts across samples are not greater than or equal to 10
# keep <- rowSums(counts(dds)) >= 10
# dds <- dds[keep,]
# run DESeq for differential expression
dds <- DESeq(dds)
# estimating size factors
# estimating dispersions
# gene-wise dispersion estimates
# mean-dispersion relationship
# final dispersion estimates
# fitting model and testing
# build results table
res <- results(dds, alpha =0.05, lfcThreshold=1)

head(res)
# log2 fold change (MLE): Type Tumor vs Normal 
# Wald test p-value: Type Tumor vs Normal 
# DataFrame with 6 rows and 6 columns
# baseMean log2FoldChange     lfcSE      stat    pvalue      padj
# <numeric>      <numeric> <numeric> <numeric> <numeric> <numeric>
#   5_8S_rRNA   4.89842       2.756320  2.971730  0.591009        NA        NA
# 5S_rRNA     3.37830      -0.217944  1.021799  0.000000  1.000000         1
# 7SK        65.96420       0.346563  0.538180  0.000000  1.000000         1
# A1BG       22.17502       0.563783  0.432765  0.000000  1.000000         1
# A1BG-AS1   87.87722      -0.606024  0.230310  0.000000  1.000000         1
# A1CF       11.18611       1.032677  0.536883  0.060865  0.951467         1

summary(res)
# out of 47835 with nonzero total read count
# adjusted p-value < 0.05
# LFC > 1.00 (up)    : 2095, 4.4%
# LFC < -1.00 (down) : 1223, 2.6%
# outliers [1]       : 1228, 2.6%
# low counts [2]     : 9127, 19%
# (mean count < 2)
# [1] see 'cooksCutoff' argument of ?results
# [2] see 'independentFiltering' argument of ?results


# subset results to include those adjusted p-value (FDR) less than 0.05
resSig <- subset(res, padj < 0.05)

# downregulation
# genes that are found to be downregulated in our result
res_down_genes <- resSig[ order(resSig$log2FoldChange), ] 
# genes whose log fold change is less than -1 (i.e. higher downregulation)
res_down_genes <- res_down_genes[ res_down_genes$log2FoldChange < -1.00, ] 
res_down_genes <- data.frame(res_down_genes)

# save the table to a file
res_down_genes <- res_down_genes %>% mutate(gene_name = rownames(res_down_genes), .before = 1)
write_delim(res_down_genes, file = 'full_table_downreg_genes.csv', delim = ',')
# res_down_gene_names <- tibble(gene_name = rownames(res_down_genes))
# write_delim(res_down_gene_names, file = 'downreg_genes.csv', delim = ',')

# upregulation
# genes that are found to be upregulated in our result
res_up_genes <- resSig[ order(resSig$log2FoldChange, decreasing = TRUE), ]
# genes whose log fold change is greater than 1 (i.e. higher upregulation)
res_up_genes <- res_up_genes[ res_up_genes$log2FoldChange  > 1.00, ] 
res_up_genes <- data.frame(res_up_genes)
res_up_genes <- res_up_genes %>% mutate(gene_name = rownames(res_up_genes), .before = 1)
write_delim(res_up_genes, file = 'full_table_upreg_genes.csv', delim = ',')
# res_up_gene_names <- tibble(gene_name = rownames(res_up_genes))
# write_delim(res_up_gene_names, file = 'upreg_genes.csv', delim = ',')

# volcano plot

if (!requireNamespace('BiocManager', quietly = TRUE))
  install.packages('BiocManager')

BiocManager::install('EnhancedVolcano')

library(EnhancedVolcano)

res_shrink <- lfcShrink(dds,
                 contrast = c('Type','Tumor','Normal'), res=res, type = 'normal')



EnhancedVolcano(res_shrink,
                lab = rownames(res_shrink),
                x = 'log2FoldChange',
                y = 'pvalue')

# plotCounts
# gene with higher counts for tumor-normal comparison
plotCounts(dds, gene='A2M', intgroup="Type")

# boxplot
res_tidy <- results(dds, tidy=TRUE, contrast=c("Type", "Tumor", "Normal")) %>%
  arrange(padj, pvalue) %>%
  tibble()
res_tidy

goi <- res_tidy$row[1:9]
stopifnot(all(goi %in% names(dds)))
goi

tcounts <- t(log2((counts(dds[goi, ], normalized=TRUE, replaced=FALSE)+.5))) %>%
  merge(colData(dds), ., by="row.names") %>%
  gather(gene, expression, (ncol(.)-length(goi)+1):ncol(.))

tcounts %>% 
  select(Row.names, Type, stage, gene, expression) %>% 
  head %>% 
  knitr::kable()

ggplot(tcounts, aes(Type, expression, fill=Type)) + 
  geom_boxplot() + 
  facet_wrap(~gene, scales="free_y") + 
  labs(x="Type", 
       y="Expression (log normalized counts)", 
       fill="Type", 
       title="Most significant differentially expressed genes based on p-values")



