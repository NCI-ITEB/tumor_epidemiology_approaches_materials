dependencies<-c("ggsci","ggrepel","scales","cowplot","tidyverse","valr","qqman")
packages_needed<-c()
for(package in dependencies)
{
  if(!requireNamespace(package,quietly = T)){
    packages_needed<-c(packages_needed,package)
  }
}
install.packages(packages_needed)

library(tidyverse)
library(ggsci)
library(ggrepel)
library(scales)
library(cowplot)

#### BOXPLOT -------------------------------------------------------------------
egfr_exp <- read_rds('~/Downloads/Practical_12/egfr_exp.RDS')

egfr_exp %>% ggplot(aes(x=Data_Type,y=Exp))

egfr_exp %>%
  ggplot(aes(x=Data_Type,y=Exp))+ 
  geom_boxplot(outlier.shape = NA)+
  geom_point()

# jitter the points to improve visibility
egfr_exp %>%
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_boxplot(outlier.shape = NA)+
  geom_point(position = position_jitter(width=0.25,height = 0.01,seed = 100))

# reorder points under boxplot, make boxplot transparent, minor changes to points
egfr_exp %>%
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_point(stroke=0.2,
             size=2.5,
             alpha=0.7,
             position = position_jitter(width=0.25,height = 0.01,seed = 100))+
  geom_boxplot(outlier.shape = NA,fill=NA)

# add color and shape, fix legends
egfr_exp %>%
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_point(aes(fill=as.factor(CNV),shape=Mutation_Status),
             col='gray95',
             stroke=0.2,
             size=2.5,
             alpha=0.7,
             position = position_jitter(width=0.25,height = 0.01,seed = 100))+
  geom_boxplot(outlier.shape = NA,fill=NA)+
  #
  scale_shape_manual(values = c(25,21))+
  guides(fill=guide_legend(override.aes=list(shape=21,size=4)),
         shape=guide_legend(override.aes=list(stroke=0.8,size=3,col='black')))

# change colors
egfr_exp %>%
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_point(aes(fill=as.factor(CNV),shape=Mutation_Status),
             col='gray95',stroke=0.2,size=2.5,alpha=0.7,
             position = position_jitter(width=0.25,height = 0.01,seed = 100))+
  geom_boxplot(outlier.shape = NA,fill=NA)+
  scale_shape_manual(values = c(25,21))+
  guides(fill=guide_legend(override.aes=list(shape=21,size=4)),
         shape=guide_legend(override.aes=list(stroke=0.8,size=3,col='black')))+
  #
  scale_fill_manual(values = c('#0c2c84','#1d91c0','gray20','#ef6548','#990000'))

# add more features
egfr_exp %>%
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_point(aes(fill=as.factor(CNV),shape=Mutation_Status),
             col='gray95',stroke=0.2,size=2.5,alpha=0.7,
             position = position_jitter(width=0.25,height = 0.01,seed = 100))+
  geom_boxplot(outlier.shape = NA,fill=NA)+
  scale_shape_manual(values = c(25,21))+
  guides(fill=guide_legend(override.aes=list(shape=21,size=4)),
         shape=guide_legend(override.aes=list(stroke=0.8,size=3,col='black')))+
  scale_fill_manual(values = c('#0c2c84','#1d91c0','gray20','#ef6548','#990000'))+
  #
  # panel by population
  facet_wrap(~Group)+
  # axis and legend labels
  labs(x='',y='EGFR RNA-Seq expression log2(CPM)',fill='Copy number',
       shape='Mutation status', title='Tumor v Normal EGFR Expression by Population, Smoking Status')+
  # add more y axis breaks
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6))+
  # change legend
  theme_bw(base_size = 13)

# add labels
egfr_exp %>%
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_point(aes(fill=as.factor(CNV),shape=Mutation_Status),
             col='gray95',stroke=0.2,size=2.5,alpha=0.7,
             position = position_jitter(width=0.25,height = 0.01,seed = 100))+
  geom_boxplot(outlier.shape = NA,fill=NA)+
  scale_shape_manual(values = c(25,21))+
  guides(fill=guide_legend(override.aes=list(shape=21,size=4)),
         shape=guide_legend(override.aes=list(stroke=0.8,size=3,col='black')))+
  scale_fill_manual(values = c('#0c2c84','#1d91c0','gray20','#ef6548','#990000'))+
  facet_wrap(~Group)+
  labs(x='',y='EGFR RNA-Seq expression log2(CPM)',fill='Copy number',
       shape='Mutation status', title='Tumor v Normal EGFR Expression by Population, Smoking Status')+
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6))+
  theme_bw(base_size = 13)+
  #
  ggrepel::geom_text_repel(aes(label=if_else((Exp>12|Exp<4),Subject,"")),
                           size=3.2,force = 20,
                           position=position_jitter(width=0.25,height = 0.01,seed = 100),
                           min.segment.length = 0.1)
  
# tilt x-axis labels minor legend changes
egfr_exp %>%
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_point(aes(fill=as.factor(CNV),shape=Mutation_Status,),
             col='gray95',stroke=0.2,size=2.5,alpha=0.7,
             position = position_jitter(width=0.25,height = 0.01,seed = 100))+
  geom_boxplot(outlier.shape = NA,fill=NA)+
  scale_shape_manual(values = c(25,21))+
  guides(fill=guide_legend(override.aes=list(shape=21,size=4)),
         shape=guide_legend(override.aes=list(stroke=0.8,size=3,col='black')))+
  scale_fill_manual(values = c('#0c2c84','#1d91c0','gray20','#ef6548','#990000'))+
  facet_wrap(~Group)+
  labs(x='',y='EGFR RNA-Seq expression log2(CPM)',fill='Copy number',
       shape='Mutation status', title='Tumor v Normal EGFR Expression by Population, Smoking Status')+
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6))+
  theme_bw(base_size = 13)+
  ggrepel::geom_text_repel(aes(label=if_else((Exp>12|Exp<4),Subject,"")),
                           size=3.2,force = 20,
                           position=position_jitter(width=0.25,height = 0.01,seed = 100),
                           min.segment.length = 0.1)+
  #
  theme(axis.text.x = element_text(angle = 45,hjust = 1,vjust = 1))

ggsave(filename = 'EGFR_Expression_style2.pdf',width = 7,height = 7,device = cairo_pdf)  

# Dual GWAS plots ---------------------------------------------------------
# Load required libraries
library(valr)
library(qqman)

# Load qqman example dataset
data("gwasResults")
gwasResults %>% as_tibble()

# Create a data frame for plotting
df <- gwasResults %>% 
  mutate(end=BP) %>% 
  select(chrom=CHR,start=BP,end,gwas_p=P,snp=SNP) %>% 
  #mutate(chrom = factor(chrom, levels = 1:22)) %>% 
  arrange(chrom, start) %>% 
  as_tibble()

# add column `pos` for x axis plotting and a color code by chromosome
df <- df %>% 
  mutate(pos=seq_along(start)) %>% 
  mutate(chrcolor=if_else(as.numeric(chrom) %% 2 == 0, '#115387','#2F69BE'))

df %>% 
  ggplot(aes(pos,-log10(gwas_p),color=chrcolor))+
  geom_point(pch=19)+
  scale_color_identity()

# find gwas locus
pthreshold <- 1e-03
locus_size=100

significant_snps <- df %>%
  filter(gwas_p < pthreshold)

# create bed-formatted table of significant snps+-locus_size
significant_gwas_locus <- significant_snps %>% 
  mutate(start=start-locus_size,end=end+locus_size)

# pull all SNPs within range 
significant_gwas_locus <- bed_intersect(df,significant_gwas_locus) %>% 
  select(chrom,start=start.x,end=end.x) %>% 
  unique() %>% 
  mutate(gwas_locus=T)

## add the Locus ID to the gwas locus
## use gap between consecutive variant entries to identify where one locus ends, next begins
significant_gwas_locus <- significant_gwas_locus %>%
  group_by(chrom) %>%
  mutate(prev_bp = lag(start)) %>%
  mutate(distance = ifelse(is.na(prev_bp), NA_integer_, start - prev_bp)) %>%
  ungroup()
#mutate(same_locus=if_else(distance<locus_size,TRUE,FALSE))

## increment locus id when bp gap > 1
significant_gwas_locus$gwas_id <- NA
gwasid <- 0
for(i in 1:dim(significant_gwas_locus)[1]){
  if(significant_gwas_locus$distance[i]>locus_size | is.na(significant_gwas_locus$distance[i])) 
  { gwasid <- gwasid+1 }
  significant_gwas_locus$gwas_id[i] <- gwasid
}

# add info to original data frame for plotting significant loci
df <- df %>% left_join(significant_gwas_locus) %>% 
  mutate(gwas_locus=if_else(is.na(gwas_locus),FALSE,gwas_locus)) %>% 
  mutate(chrcolor=if_else(gwas_locus, if_else(as.numeric(chrom) %% 2 == 0, '#530225','#AE1B8C'),chrcolor))

# xdata stores position of chromosome x-axis labels, ydata stores labeling information
xdata <- df %>% group_by(chrom) %>% slice(ceiling(n()/2)) %>% ungroup() %>% select(chrom,pos)
ydata <- df %>% filter(gwas_locus) %>% group_by(gwas_id) %>% arrange(gwas_p) %>% slice(1) %>% ungroup()

p1 <- df %>% 
  ggplot(aes(x=pos,y=-log10(gwas_p),color=chrcolor))+
  geom_point(pch=19,size=1)+
  scale_color_identity()+
  geom_point(data = ydata ,pch=23,size=2)+
  ggrepel::geom_text_repel(data = ydata,aes(label=snp),nudge_y = 0.5)+
  geom_hline(yintercept = -log10(pthreshold),linetype=2,size=0.4)+
  annotate(geom = 'text',x = 0.9*max(df$pos),y=8.5,label="Stage 1 GWAS",fontface = "bold")+
  scale_y_continuous(breaks = c(0,2,4,6,8),expand = c(0.01,0.01))+
  scale_x_continuous(breaks = xdata$pos,labels = xdata$chrom,expand = c(0.01,0.01))+
  labs(x='',y=expression(-log[10](P-value)))+
  theme_minimal(base_family = 'Arial',base_size = 14)+
  theme(panel.grid = element_blank(),
        axis.line.y = element_line(linewidth = 0.4),
        axis.ticks.y=element_line())

## dual manhattan plot
## you can process the second data the same as df. here, we just use the same data for second manhattan plot. 

p2 <- df %>% 
  ggplot(aes(pos,-log10(gwas_p),color=chrcolor))+
  geom_hline(yintercept = -log10(pthreshold),linetype=2,size=0.4)+
  geom_point(pch=19,size=1)+
  geom_point(data = ydata ,pch=23,size=2)+
  ggrepel::geom_text_repel(data = ydata,aes(label=snp),nudge_y = -0.5)+
  annotate(geom = 'text',x = 0.9*max(df$pos),y=8.5,label="Stage 2 GWAS",fontface = "bold")+
  scale_color_identity()+
  scale_y_reverse(breaks = c(0,2,4,6,8),expand = c(0.01,0.01))+
  scale_x_continuous(breaks = xdata$pos,labels = xdata$chrom,expand = c(0.01,0.01),position = 'top')+
  labs(x='',y=expression(-log[10](P-value)))+
  theme_minimal(base_family = 'Arial',base_size = 14)+
  theme(panel.grid = element_blank(),axis.line.y = element_line(linewidth = 0.4),
        axis.ticks.y=element_line(),axis.text.x = element_blank())

pall <- cowplot::plot_grid(p1+theme(plot.margin = margin(t=4,b=-12)),
                           p2+theme(plot.margin = margin(t=-12,b=4)),
                           axis = 'lr',ncol = 1)

ggsave(filename = 'Manhattan_plot_style2.pdf',plot = pall,width = 9,height = 8,device = cairo_pdf)  