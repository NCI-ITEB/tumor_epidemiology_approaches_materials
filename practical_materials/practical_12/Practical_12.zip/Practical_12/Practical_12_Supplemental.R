# Violin Plot ----------------------------------------------------------------

# create a grid
egfr_exp %>% ggplot(mapping=aes(x=Data_Type,y=Exp,fill=Data_Type))

# add violins
egfr_exp %>% 
  ggplot(aes(x=Data_Type,y=Exp,fill=Data_Type))+
  geom_violin()

# add boxplots
egfr_exp %>% 
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_violin(aes(fill=Data_Type))+ 
  geom_boxplot()

# reformat boxes to fit within violins
egfr_exp %>% 
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_violin(aes(fill=Data_Type))+ 
  geom_boxplot(width=0.1, fill="gray80",outlier.shape = 21,outlier.size = 2.5)

# change axis titles
egfr_exp %>% 
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_violin(aes(fill=Data_Type))+ 
  geom_boxplot(width=0.1, fill="gray80",outlier.shape = 21,outlier.size = 2.5)+
  labs(x='',y='EGFR RNA-Seq expression log2(CPM)')

# edit colors, remove redundant legend
egfr_exp %>% 
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_violin(aes(fill=Data_Type))+ 
  geom_boxplot(width=0.1, fill="gray80",outlier.shape = 21,outlier.size = 2.5)+
  labs(x='',y='EGFR RNA-Seq expression log2(CPM)')+
  ggsci::scale_fill_nejm()+
  guides(fill='none')

# separate samples by population origin
egfr_exp %>% 
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_violin(aes(fill=Data_Type))+ 
  geom_boxplot(width=0.1, fill="gray80",outlier.shape = 21,outlier.size = 2.5)+
  labs(x='',y='EGFR RNA-Seq expression log2(CPM)')+
  ggsci::scale_fill_nejm()+
  guides(fill='none')+
  facet_wrap(~Group,nrow=1,scales="free_y")

# add more breaks to the y-axis
egfr_exp %>% 
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_violin(aes(fill=Data_Type))+ 
  geom_boxplot(width=0.1, fill="gray80",outlier.shape = 21,outlier.size = 2.5)+
  labs(x='',y='EGFR RNA-Seq expression log2(CPM)')+
  ggsci::scale_fill_nejm()+
  guides(fill='none')+
  facet_wrap(~Group,nrow=1,scales="free_y")+
  scale_y_continuous(breaks = scales::pretty_breaks(n = 7))

# change theme
egfr_exp %>% 
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_violin(aes(fill=Data_Type))+ 
  geom_boxplot(width=0.1, fill="gray80",outlier.shape = 21,outlier.size = 2.5)+
  labs(x='',y='EGFR RNA-Seq expression log2(CPM)')+
  ggsci::scale_fill_nejm()+
  guides(fill='none')+
  facet_wrap(~Group,nrow=1,scales="free_y")+
  scale_y_continuous(breaks = scales::pretty_breaks(n = 7))+
  theme_bw(base_size=13)

# use different theme
egfr_exp %>% 
  ggplot(aes(x=Data_Type,y=Exp))+
  geom_violin(aes(fill=Data_Type))+
  geom_boxplot(width=0.1, fill="gray80",outlier.shape = 21,outlier.size = 2.5)+
  labs(x='',y='EGFR RNA-Seq expression log2(CPM)')+
  guides(fill='none')+
  scale_fill_nejm()+
  facet_wrap(~Group,nrow = 1,scales = 'free_y')+
  scale_y_continuous(breaks = scales::pretty_breaks(n = 7))+
  hrbrthemes::theme_ipsum_rc(axis_text_size = 14,axis_title_just = 'm',axis_title_size = 16,grid = 'XY')+
  cowplot::panel_border(color = 'black')

# save plot
ggsave(filename = 'EGFR_Expression_style1.pdf',width = 7,height = 7,device = cairo_pdf)  