library(revolver)
library(evoverse.datasets)

# data("TRACERx_NEJM_2017", package = "evoverse.datasets")
# 
# subset_data = TRACERx_NEJM_2017 %>%
#   filter(patientID %in% c("CRUK0001", "CRUK0002", "CRUK0003"))
# 
# my_cohort = revolver_cohort(
#   dataset = subset_data, 
#   CCF_parser = CCF_parser,
#   ONLY.DRIVER = FALSE, 
#   MIN.CLUSTER.SIZE = 0,
#   annotation = "My small REVOLVER dataset"
# )
# 
# print(my_cohort)
# plot(my_cohort)
# 
# data("TRACERx_NEJM_2017_REVOLVER", package = "evoverse.datasets")
# print(TRACERx_NEJM_2017_REVOLVER)
# plot(TRACERx_NEJM_2017_REVOLVER)
# 
# plot_clusters(TRACERx_NEJM_2017_REVOLVER)
# plot_dendrogram(TRACERx_NEJM_2017_REVOLVER)
# plot_jackknife_coclustering(TRACERx_NEJM_2017_REVOLVER)

data(CROSS_CRC_ADENOCARCINOMA_NATECOEVO_2018, package = 'evoverse.datasets')
print(CROSS_CRC_ADENOCARCINOMA_NATECOEVO_2018)

CROSS_CRC_ADENOCARCINOMA_REVOLVER = revolver_cohort(
  CROSS_CRC_ADENOCARCINOMA_NATECOEVO_2018, 
  MIN.CLUSTER.SIZE = 0, 
  annotation = "Colorectal adenocarcinomas (Cross et al, PMID 30177804)")

# Run a check on the cohort to flag drivers that occur only once
revolver_check_cohort(CROSS_CRC_ADENOCARCINOMA_REVOLVER)
# Collect names of drivers occuring only once, then remove from the cohort
non_recurrent = Stats_drivers(CROSS_CRC_ADENOCARCINOMA_REVOLVER) %>% 
  filter(N_tot == 1) %>% 
  pull(variantID)
CROSS_CRC_ADENOCARCINOMA_REVOLVER = remove_drivers(CROSS_CRC_ADENOCARCINOMA_REVOLVER, non_recurrent)

# Build mutation trees
CROSS_CRC_ADENOCARCINOMA_REVOLVER = compute_mutation_trees(CROSS_CRC_ADENOCARCINOMA_REVOLVER)
CROSS_CRC_ADENOCARCINOMA_REVOLVER = revolver_fit(
  CROSS_CRC_ADENOCARCINOMA_REVOLVER, 
  parallel = F, 
  n = 3, 
  initial.solution = NA)
# Run hierarchical clustering
CROSS_CRC_ADENOCARCINOMA_REVOLVER = revolver_cluster(
  CROSS_CRC_ADENOCARCINOMA_REVOLVER, 
  split.method = 'cutreeHybrid',
  min.group.size = 3)
# Plot clusters
plot_clusters(CROSS_CRC_ADENOCARCINOMA_REVOLVER, cutoff_trajectories = 1, cutoff_drivers = 0)
plot_trajectories_per_cluster(CROSS_CRC_ADENOCARCINOMA_REVOLVER, min_counts = .3) 
plot_drivers_graph(CROSS_CRC_ADENOCARCINOMA_REVOLVER)
