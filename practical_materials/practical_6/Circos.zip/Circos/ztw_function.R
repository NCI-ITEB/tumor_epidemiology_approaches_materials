circos.genomicInitialize2 = function(data, sector.names = NULL, major.by = NULL,
                                    plotType = c("axis", "labels"), tickLabelsStartFromZero = TRUE, 
                                    track.height = convert_height(3, "mm"), ...) {
  
  if(is.factor(data[[1]])) {
    fa = levels(data[[1]])
  } else {
    fa = unique(data[[1]])
  }
  
  if(!is.null(sector.names)) {
    if(length(sector.names) != length(fa)) {
      stop("length of `sector.names` and length of sectors differ.")
    }
  } else {
    sector.names = fa
  }
  
  names(sector.names) = fa
  
  # calculate xlim
  x1 = tapply(data[[2]], data[[1]], min)[fa]
  x2 = tapply(data[[3]], data[[1]], max)[fa]
  
  op = circos.par("cell.padding")
  ow = circos.par("points.overflow.warning")
  circos.par(cell.padding = c(0, 0, 0, 0), points.overflow.warning = FALSE)
  #circos.initialize(factor(fa, levels = fa), xlim = cbind(x1, x2), ...)
  
  # axis and chromosome names
  if(any(plotType %in% c("axis", "labels"))) {
    circos.genomicTrackPlotRegion(data, ylim = c(0, 1), bg.border = NA, track.height = track.height,
                                  panel.fun = function(region, value, ...) {
                                    sector.index = get.cell.meta.data("sector.index")
                                    xlim = get.cell.meta.data("xlim")
                                    
                                    if(tickLabelsStartFromZero) {
                                      offset = xlim[1]
                                      if(is.null(major.by)) {
                                        xlim = get.cell.meta.data("xlim")
                                        major.by = .default.major.by()
                                      }
                                      major.at = seq(xlim[1], xlim[2], by = major.by)
                                      major.at = c(major.at, major.at[length(major.at)] + major.by)
                                      
                                      if(major.by > 1e6) {
                                        major.tick.labels = paste((major.at-offset)/1000000, "MB", sep = "")
                                      } else if(major.by > 1e3) {
                                        major.tick.labels = paste((major.at-offset)/1000, "KB", sep = "")
                                      } else {
                                        major.tick.labels = paste((major.at-offset), "bp", sep = "")
                                      }
                                      
                                    } else {
                                      if(is.null(major.by)) {
                                        xlim = get.cell.meta.data("xlim")
                                        major.by = .default.major.by()
                                      }
                                      major.at = seq(floor(xlim[1]/major.by)*major.by, xlim[2], by = major.by)
                                      major.at = c(major.at, major.at[length(major.at)] + major.by)
                                      
                                      if(major.by > 1e6) {
                                        major.tick.labels = paste(major.at/1000000, "MB", sep = "")
                                      } else if(major.by > 1e3) {
                                        major.tick.labels = paste(major.at/1000, "KB", sep = "")
                                      } else {
                                        major.tick.labels = paste(major.at, "bp", sep = "")
                                      }
                                    }
                                    
                                    
                                    if(all(c("axis", "labels") %in% plotType)) {
                                      circos.axis(h = 0, major.at = major.at, labels = major.tick.labels, labels.cex = 0.4*par("cex"))
                                      circos.text(mean(xlim), 1.3, labels = sector.names[sector.index], cex = par("cex"), adj = c(0.5, 0), niceFacing = TRUE)
                                    } else if("labels" %in% plotType) {
                                      circos.text(mean(xlim), 0, labels = sector.names[sector.index], cex = par("cex"), adj = c(0.5, 0), niceFacing = TRUE,font=2)
                                    } else if("axis" %in% plotType) {
                                      circos.axis(h = 0, major.at = major.at, labels = major.tick.labels, labels.cex = 0.28*par("cex"))
                                    }
                                  }
    )
  }
  
  
  circos.par("cell.padding" = op, "points.overflow.warning" = ow)
  return(invisible(NULL))
}


environment(circos.genomicInitialize2) <- asNamespace('circlize')
# environment(circos.genomicInitialize2) <- as.environment("package:circlize")

circos.initializeWithIdeogram2 = function(cytoband = system.file(package = "circlize",
                                                                "extdata", "cytoBand.txt"), species = NULL, sort.chr = TRUE,
                                         chromosome.index = NULL, major.by = NULL,
                                         plotType = c("ideogram", "axis", "labels"), 
                                         track.height = convert_height(3, "mm"), ideogram.height = convert_height(2, "mm"), 
                                         ...) {
  
  # proper order will be returned depending on cytoband and sort.chr
  e = try(cytoband <- read.cytoband(cytoband, species = species, sort.chr = sort.chr, chromosome.index = chromosome.index), silent = TRUE)
  if(class(e) == "try-error" && !is.null(species)) {  # if species is defined
    e2 = try(cytoband <- read.chromInfo(species = species, sort.chr = sort.chr, chromosome.index = chromosome.index), silent = TRUE)
    if(class(e2) == "try-error") {
      message(e)
      message(e2)
      stop("Cannot download either cytoband or chromInfo file from UCSC.")
    } else {
      message_wrap("Downloading cytoBand file from UCSC failed. Use chromInfo file instead. Note ideogram track will be removed from the plot.")
      plotType = setdiff(plotType, "ideogram")
      
      # because in chromInfo file, there are also many short scaffold
      if(is.null(chromosome.index)) {
        chromInfo = read.chromInfo(species = species)
        chr_len = sort(chromInfo$chr.len, decreasing = TRUE)
        
        # sometimes there are small scaffold
        i = which(chr_len[seq_len(length(chr_len)-1)] / chr_len[seq_len(length(chr_len)-1)+1] > 5)[1]
        if(length(i)) {
          chromosome = chromInfo$chromosome[chromInfo$chromosome %in% names(chr_len[chr_len >= chr_len[i]])]
        } else {
          chromosome = chromInfo$chromosome
        }
        cytoband = read.chromInfo(species = species, chromosome.index = chromosome, sort.chr = sort.chr)
      } 
    }
  } else if(class(e) == "try-error") {
    stop(e)
  }
  df = cytoband$df
  chromosome = cytoband$chromosome
  
  if(is.null(chromosome.index)) {
    chromosome.index = chromosome
  }
  
  # here df[[1]] is quite important, should be re-factered
  df[[1]] = factor(as.vector(df[[1]]), levels = chromosome.index)
  
  # sn for sector names, but not for sector index
  sn = unique(as.vector(df[[1]]))
  
  # we do not need 'chr' prefix if it exits, it holds too much space.
  sn = gsub("chr", "", sn)
  
  o.cell.padding = circos.par("cell.padding")
  circos.par(cell.padding = c(o.cell.padding[1], 0, o.cell.padding[3], 0))
  
  circos.genomicInitialize2(df, sector.names = sn, major.by = major.by, plotType = plotType, track.height = track.height, ...)
  
  if(any(plotType %in% "ideogram")) {
    circos.genomicIdeogram(df, track.height = ideogram.height)
  }
}

environment(circos.initializeWithIdeogram2) <- asNamespace('circlize')
#environment(circos.initializeWithIdeogram2) <- as.environment("package:circlize")

