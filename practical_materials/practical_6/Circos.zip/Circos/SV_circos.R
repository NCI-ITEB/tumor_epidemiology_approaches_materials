# Set the working directory to the location where the script is saved
# setwd(".")

# Load the tidyverse and circlize libraries
library(tidyverse)
library(circlize)

# Load the 'ztw_function.R' file which contains small functions for producing SV graphics
source('ztw_function.R')

# Load the 'svdata.RData' file
load('svdata.RData')

# Define the colors for the different structural variant (SV) types
#Extract the unique SV types from the 'svdata' data frame
svtypes <- unique(svdata$sv_type)

# Define the colors to be used for each SV type
svcolor <- c("#BB0E3D", "#ff7f00", "#4daf4a", "#007BBD", "#984ea3", "#467E84")

# Assign the colors to the SV types
names(svcolor) <- svtypes

# Add the 'color' column to the 'svdata' data frame, 
# with the color corresponding to each SV type
svdata <- svdata %>% mutate(color = svcolor[sv_type])

# Create a barplot of the number of SVs for each SV type, reordered by the number of SVs
barplot <- svdata %>% 
  count(sv_type) %>% 
  mutate(sv_type = fct_reorder(sv_type,n)) %>%
  ggplot(aes(x=sv_type,y=n,fill=sv_type)) + 
  geom_col(width = 0.7, col = 'black', linewidth = 0.4) + 
  scale_fill_manual(values = svcolor, breaks = names(svcolor)) + 
  labs(x = '', y = 'Number of SVs', fill = 'SV type', title = 'NSLC-0463-T01') + 
  theme_bw(base_size = 15, base_line_size = 0.25) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1))
## Line by line annotations
# count(sv_type) %>%: counts the number of occurrences of each unique value in the column sv_type and assigns the output to the next step in the pipe.
# mutate(sv_type = fct_reorder(sv_type,n)) %>%: reorders the levels of the sv_type column based on the count (n) of each level.
# ggplot(aes(sv_type,n,fill=sv_type)) +: creates a bar plot using ggplot() with the sv_type column on the x-axis, the count (n) on the y-axis, and the sv_type column used to fill the bars.
# geom_col(width = 0.7, col = 'black', linewidth = 0.4) +: adds a column geom to the plot, with a width of 0.7, a color of black, and a line width of 0.4.
# scale_fill_manual(values = svcolor, breaks = names(svcolor)) +: sets the fill color of the bars using the color palette svcolor and the level names of sv_type
# labs(x = '', y = 'Number of SVs', fill = 'SV type', title = 'NSLC-0463-T01') +: sets labels for the x-axis, y-axis, fill, and title of the plot
# theme_bw(base_size = 15, base_line_size = 0.25) +: sets the theme of the plot with a base font size of 15 and base line size of 0.25
# theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)): Changes the angle of the x-axis text to 45 degrees and adjusts the horizontal and vertical justification of the text to the right and top respectively.
# barplot<-: Save the final plot to the variable `barplot`

# Show the plot
barplot

# Save the barplot as a PDF file
#ggsave(filename = 'NSLC-0463-T01_barplot.pdf', width = 8, height = 8)

# Circos Plots

# Extract the data for the Circos plot

# Adding 2000000 to the end position of the SV breakpoints when extracting the data for the Circos plot. 
# By increasing the size of the breakpoints to 2 Mbp, they will be more visible in the Circos plot. 
fix = 2000000

# Extract the data for the breakpoints 'A', adding 2000000 to the end position
bed1 <- svdata %>% 
  mutate(posA2 = posA + fix) %>% # create a column, posA2, 2Mbp downstream of posA...
  select(chr = chrA, start = posA, end = posA2, color) %>% # extract columns chrA, posA, posA2, color, and rename them... 
  as.data.frame()

# Extract the data for the breakpoints 'B', adding 2000000 to the end position
bed2 <- svdata %>% 
  mutate(posB2 = posB + fix) %>% # create a column, posB2, 2Mbp downstream of posB
  select(chr = chrB, start = posB, end = posB2, color) %>% # extract columns chrB, posB, posB2, color, and rename them 
  as.data.frame() 

# Extract the data for the breakpoints 'A' that have associated genes, adding 2000000 to the end position
bed_gene1 <- svdata %>% 
  mutate(posA2 = posA + fix) %>% 
  select(chr = chrA, start = posA, end = posA2, gene = geneA, color) %>% 
  filter(!is.na(gene)) %>% # remove SVs without an associated gene
  as.data.frame()

# Extract the data for the breakpoints 'B' that have associated genes, adding 2000000 to the end position
bed_gene2 <- svdata %>% 
  mutate(posB2 = posB + fix) %>% 
  select(chr = chrB, start = posB, end = posB2, gene = geneB, color) %>% 
  filter(!is.na(gene)) %>% # remove SVs without an associated gene
  as.data.frame()

# Combine the data for the 'A' and 'B' breakpoints, group by gene, and keep only the first instance of each gene
bed_gene <- bind_rows(bed_gene1, bed_gene2) %>% 
  group_by(gene) %>% 
  mutate(n = length(gene)) %>% 
  mutate(gene = if_else(n > 1, paste0(gene, "**"), gene)) %>% 
  slice(1) %>% 
  ungroup() %>% 
  arrange(chr, start, end) %>%  
  as.data.frame()
## Detailed annotations for the code above
# bind_rows(bed_gene1, bed_gene2) %>%: bind_rows() combines the two data frames bed_gene1 and bed_gene2 by adding the rows of the second data frame to the bottom of the first data frame.
# group_by(gene) %>%: groups the rows of bed_gene by the gene column
# mutate(n = length(gene)) %>%: adds a new column called n that counts the number of SVs per gene.
# mutate(gene = if_else(n > 1, paste0(gene, "**"), gene)) %>%: adds an asterisk (**) to the gene column for all genes with more than 1 SV.
# slice(1) %>%: Selects the first row from each gene (reminder: this table is for the annotations along the outside of the plot, so we just need one per gene)
# ungroup() %>%: Stop grouping by gene
# arrange(chr, start, end) %>%: sorts the data frame by the chr, start and end columns in that order
# as.data.frame(): Converts the final output to a data frame
# bed_gene <- : saves the final output to variable bed_gene

# Open a PDF file to save the Circos plot
#pdf(file = "NSLC-0463-T01_circos.pdf", height = 7, width = 7)

# Clear any previous plot and initialize the Circos
circos.clear()
circos.initializeWithIdeogram(plotType = NULL)

# If there are genes associated with the SVs, add a track showing the gene locations and gene name
if(dim(bed_gene)[1]>0){
  circos.genomicLabels(bed_gene, labels.column = 4, col=bed_gene$color,side = "outside",cex = 0.4,line_lwd = 0.5,track.margin = c(0,-0.1))
} else {
  # If there are no genes associated with the SVs, add an empty track
  circos.track(ylim = c(0, 1), bg.col = NULL,bg.border="White",track.height = convert_height(6, "mm"))
}

# initialize the Circos with chromosome labels only
circos.initializeWithIdeogram2(plotType = c("labels"))
# initialize the Circos with chromosome axis and ideogram only
circos.initializeWithIdeogram2(plotType = c("ideogram","axis"),ideogram.height = 0.04,track.height = 0.02,major.by = 5e7 )

# add the genomic links between two breakpoints. 
if(dim(bed1)[1]>0 & dim(bed2)[1]>0 ){
  circos.genomicLink(bed1, bed2, border = NA,col = bed1$color)
}

# Stop saving to the PDF file
#dev.off()