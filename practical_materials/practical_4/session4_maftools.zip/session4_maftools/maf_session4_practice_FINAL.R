# Emerging Approaches for Tumor Analyses in Epidemiological Studies Course
# Session 4 Practical Session - 01/11/2023
# Introduction to maftools

# maftools is a R package designed to summarize, analyze, annotate, and visualize Mutation Annotation Format (MAF) files. 
# Today, we will be using the maftools package to analyze and visualize the data within a MAF file.

#Install and load maftools package in R

## Install the maftools package

# If you haven’t done so already, you will need to install the maftools package. Use the following code to do so:
# install BiocManager if not already installed
if (!require("BiocManager")) 
  install.packages("BiocManager")
# install maftools if not already installed
BiocManager::install("maftools")

# The code above installs BiocManager if it is not already installed, and then uses BiocManager to install the maftools package.  
# BiocManager is a package manager for the Bioconductor repository, which includes a series of R packages used for genomic analysis.

# After maftools is sucessfully installed, load the package using the following command:
library(maftools)

# Additional Information: For some functions in exercises not being demonstrated today but available as supplemental information, 
# you will need to use the tidyverse package. Install the tidyverse package if you do not already have it installed. Then load tidyverse. 
# This package contains a group of R packages that are useful for data analyses and visualization. 
# Uncomment lines 29-34 to run
# if(!('tidyverse' %in% installed.packages())){
#   install.packages('tidyverse')
#   library(tidyverse)
# }else{
#   library(tidyverse)
# }

#Load the data into R

# Use the following command to see what your current working directory is:
getwd()

# Since you opened this file directly from the `session4_maftools` folder you created, 
# your working directory should like the following, depending on your operating system: 
  
# Mac:
# /Users/[username]/Downloads/session4_maftools

# Windows:
# C:/Users/[username]/Downloads/session4_maftools

# If the working directory is not the session4_maftools directory, use the setwd() command 
# to set this directory as the working directory.
# Uncomment the line you need to run below:
  
# Mac:
# setwd("/Users/[username]/Downloads/session4_maftools")
# Windows:
# setwd("C:/Users/[username]/Downloads/session4_maftools")

# Then run getwd() again to make sure the working directory is now correct:
  
getwd()

# Load the MAF file
tcga_luad_maf <- read.maf(maf='tcga_luad_maf_final.gz') 

#Summarize the mutation data

# Summary of mutation data
tcga_luad_maf

# Additional commands not being covered today. Uncomment the command to run it. 
# Uncomment lines 73-76 to run.
# getSampleSummary(tcga_luad_maf) %>% View()
# getGeneSummary(tcga_luad_maf) %>% View()
# getFields(tcga_luad_maf)
# write.mafSummary(maf=tcga_luad_maf, basename='tcga_luad')

#Visualization and anaysis of MAF data
# plotmafSummary()
plotmafSummary(maf = tcga_luad_maf, rmOutlier = TRUE, addStat = 'median', dashboard = TRUE, titvRaw = FALSE)

# oncoplot()

# oncoplot for the top 10 most mutated genes in the TCGA-LUAD samples
oncoplot(maf = tcga_luad_maf, top = 10)

# oncoplot for specific genes - TP53, KRAS, and EGFR
oncoplot(maf = tcga_luad_maf, genes = c('TP53','KRAS','EGFR'))

# lollipopPlot()

# lollipopPlot for TP53
lollipopPlot(maf=tcga_luad_maf, gene= 'TP53', AACol = 'HGVSp_Short', showMutationRate = TRUE, labelPos=c(175,245,273))

# plot where we label all of the amino acid changes
lollipopPlot(maf = tcga_luad_maf, gene = 'KRAS', AACol = 'HGVSp_Short', showMutationRate = TRUE, labelPos = 'all')

# Tip: If your KRAS plot is a bit cluttered along the protein domains, stretch the plot window in R or click ‘Zoom’ and then make the window larger.

# rainfallPlot()

# Direct R to where this file is stored, using the system.file() function. We are pointing R to the extdata folder in the maftools package, where the file, brca.maf.gz, is located:
brca <- system.file("extdata", "brca.maf.gz", package = "maftools")

# Use the read.maf() function as we did before to read in the TCGA-LUAD data
brca <- read.maf(maf = brca, verbose = FALSE)

# Use this data to generate the rainfall plot. By default, the plot is generated for the most mutated sample, but a sample name can be provided if desired by using the tsb argument.
rainfallPlot(maf=brca, pointSize = 0.4, detectChangePoints = TRUE)

# Additional commands not being covered today. Uncomment the command to run it. 
# TMB for TCGA-LUAD samples to explore samples for kataegis events
# Uncomment lines 115, 118, 121, and 125 to run.
#This first command runs the tmb() function available in maftools:
#tmb_tcga_luad <- tmb(tcga_luad_maf, logScale = TRUE)

# Arranges the results table so samples with higher numbers of mutations are first in the table rather than last
#tmb_tcga_luad <- tmb_tcga_luad %>% arrange(desc(total))

# Only pull the first ten tumor barcodes
#tsb <- tmb_tcga_luad$Tumor_Sample_Barcode[1:10]

# Run the rainfallPlot() function for each tumor sample barcode to see if there are any events. 
# Hint: To save you some time, you will one kataegis event for the fourth tumor sample barcode in the top 10 (denoted by tsb[4])
#rainfallPlot(maf=tcga_luad_maf, pointSize = 0.4, detectChangePoints = TRUE, tsb= tsb[4])

# tcgaCompare()

# b,l,t,r
# make outer plot margins a little bigger so that our plot isn’t cut off:
par(oma=c(2,5,2,2))

tcga_luad_mutload <- tcgaCompare(maf = tcga_luad_maf, cohortName = 'Example Data', logscale = TRUE, capture_size = 35.8)
tcga_luad_mutload

# reset to default plot parameters
dev.off()

# somaticInteractions()

# adjust left and top outer margins so that plot text and labels are not cut off
par(oma=c(0,1,0.5,0))

# top 10 genes in TCGA-LUAD data
somaticInteractions(maf = tcga_luad_maf, top = 10, pvalue = c(0.05,0.1),nShiftSymbols = 2)

# specific genes of our choosing in the TCGA-LUAD data
somaticInteractions(maf = tcga_luad_maf, genes = c('KRAS','EGFR','ERBB4','NTRK3','NF1','PDGFRA','BRAF','ALK','ROS1','NRTK2'), pvalue = c(0.05,0.1), nShiftSymbols = 2)

# reset to default plot pararmeters
dev.off()

# use the oncoplot to double check the relationship between two genes. For example, only one sample carries both KRAS and EGFR mutations in the TCGA-LUAD cohort, validating the mutually exclusive event.
oncoplot(maf = tcga_luad_maf, genes = c('KRAS','EGFR'))

# OncogenicPathways() and PlotOncogenicPathways()
OncogenicPathways(maf = tcga_luad_maf)

# RTK-RAS pathway
PlotOncogenicPathways(maf = tcga_luad_maf, pathways = "RTK-RAS")

# TP53 pathway
PlotOncogenicPathways(maf = tcga_luad_maf, pathways = "TP53")



  


